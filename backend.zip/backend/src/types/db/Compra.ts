export default interface Compra {
    IdTransaccion: string
    Total: number
    Fecha: Date
    IdSede: number
    IdServicio: number
}