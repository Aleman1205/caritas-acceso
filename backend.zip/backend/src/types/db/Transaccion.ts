export interface Transaccion {
    Id: string;
    Fecha: string;
};

export const defaultTransaccion: Transaccion = {
    Id: "",
    Fecha: ""
};
