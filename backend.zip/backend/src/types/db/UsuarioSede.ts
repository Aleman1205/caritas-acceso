export interface UsuarioSede {
	Email: string;
  IdSede: number;
}

export const defaultUsuarioSede: UsuarioSede = {
  Email:"",
  IdSede: 1
};
