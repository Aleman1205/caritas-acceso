// backend/src/utils/validadores/requests/compra.ts

// (Opcional) tipa lo que esperas en el body:
export type CompraBody = {
  Id?: number | string;
  // agrega aquí los campos reales si ya los conoces:
  // Monto?: number;
  // Moneda?: string;
  // ...
};

/**
 * Stub con API "tipo Zod" para no romper los handlers:
 * - .parse(data): devuelve el mismo data (lanza si quieres validar)
 * - .safeParse(data): { success, data | error }
 */
export const CompraValidador = {
  parse<T = any>(data: T): T {
    // Aquí podrías validar y lanzar Error si algo va mal.
    return data;
  },
  safeParse<T = any>(data: T): { success: true; data: T } | { success: false; error: string } {
    // Aquí podrías hacer validaciones reales. Por ahora, pasa todo.
    return { success: true, data };
  },
};

export default CompraValidador;
